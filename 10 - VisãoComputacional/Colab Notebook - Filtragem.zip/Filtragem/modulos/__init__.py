'''
O arquivo vazio chamado __init__.py está aqui para sinalizar 
para o interpretador Python interpreter que este diretório é 
um pacote Python que contém módulos Python
Um módulo Python é um simplesmente um arquivo .py comum 
que faz parte de um pacote Python.
assim fica mais fácil de realizar a importação de módulos
Python pessoais utilizando a declaração import
'''